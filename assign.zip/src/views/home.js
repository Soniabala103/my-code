import React, { Fragment } from "react";

import { Hero, Content } from "../components";

const Home = () => (
  <Fragment>
   
  </Fragment>
);

export default Home;
