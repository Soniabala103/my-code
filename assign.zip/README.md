# Easy User Authentication for React Apps

## Get Started

Install project dependencies:

```bash
yarn
```

Run the project:

```bash
yarn start
```